package com.yanderemod.client;

import com.yanderemod.entity.YandereEntity;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;

/**
 * Модель яндере з трьома станами анімації:
 *  1) Агресія   — ніж піднятий, тремтіння рук, труська голови, погляд «вниз» на жертву.
 *  2) Закохана  — нахил голови набік, що повільно погойдується; на місці — руки зчеплені перед собою.
 *  3) Звичайна  — ванільна ходьба/дихання.
 * Удар ножем (attackTime) додається поверх піднятої руки, тому замах працює.
 */
public class YandereModel extends PlayerModel<YandereEntity> {

    public YandereModel(ModelPart root) {
        super(root, true); // true = тонкі руки (slim)
    }

    @Override
    public void setupAnim(YandereEntity e, float limbSwing, float limbSwingAmount,
                          float age, float netHeadYaw, float headPitch) {
        super.setupAnim(e, limbSwing, limbSwingAmount, age, netHeadYaw, headPitch);

        boolean aggressive = e.isAggressive();
        boolean obsessed = e.isObsessed();
        boolean still = limbSwingAmount < 0.05F;

        if (aggressive) {
            float tremble = Mth.sin(age * 1.9F) * 0.06F;
            float jitter = Mth.cos(age * 2.3F) * 0.04F;

            // права рука з ножем піднята (+ тремтіння); замах додається поверх
            this.rightArm.xRot += -1.15F + tremble;
            this.rightArm.zRot += 0.12F + jitter;
            // ліва рука напоготові
            this.leftArm.xRot = -0.5F + tremble;
            this.leftArm.yRot = 0.3F;
            this.leftArm.zRot = -0.1F + jitter;

            // голова: погляд спідлоба + нервове сіпання
            this.head.xRot += 0.2F;
            this.head.zRot = Mth.sin(age * 0.9F) * 0.07F;
        } else if (obsessed) {
            // голова мило нахилена набік і повільно погойдується
            this.head.zRot = 0.22F + Mth.sin(age * 0.04F) * 0.05F;

            if (still) {
                // руки зчеплені перед грудьми (з легким диханням)
                float breathe = Mth.sin(age * 0.067F) * 0.03F;
                this.rightArm.xRot = -0.95F + breathe;
                this.rightArm.yRot = -0.45F;
                this.rightArm.zRot = 0.0F;
                this.leftArm.xRot = -0.95F - breathe;
                this.leftArm.yRot = 0.45F;
                this.leftArm.zRot = 0.0F;
            }
        }

        // PlayerModel копіює частини до нашого коду — синхронізуємо верхній шар скіна
        this.hat.copyFrom(this.head);
        this.leftSleeve.copyFrom(this.leftArm);
        this.rightSleeve.copyFrom(this.rightArm);
    }
}
